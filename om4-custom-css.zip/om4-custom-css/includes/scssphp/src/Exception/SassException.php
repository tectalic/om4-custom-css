<?php

namespace OM4\Vendor\ScssPhp\ScssPhp\Exception;

interface SassException
{
}
